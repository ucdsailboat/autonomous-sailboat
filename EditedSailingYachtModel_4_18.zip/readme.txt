﻿To run this simulation in Matlab:

1) Put all the files

f.m

SailingYachtModel.slx

SailingYachtAnimation.wrl

water.jpg

in the current matlab folder,



2) open Simulink file “SailingYachtModel.slx” and run it.



(runs on Matlab r2013a, Simulink 8.1, Simulink 3D Animation 7.0)



%%%%%%%%%%%%%%%%%%%%%%


Jerome Jouffroy, University of Southern Denmark, 2014.