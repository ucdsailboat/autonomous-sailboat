/*
 * EditedSailingYachtModel_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "EditedSailingYachtModel".
 *
 * Model version              : 1.856
 * Simulink Coder version : 8.12 (R2017a) 16-Feb-2017
 * C source code generated on : Wed Apr 18 12:55:08 2018
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->Unspecified (assume 32-bit Generic)
 * Code generation objective: Execution efficiency
 * Validation result: Passed (10), Warnings (2), Error (0)
 */

#ifndef RTW_HEADER_EditedSailingYachtModel_types_h_
#define RTW_HEADER_EditedSailingYachtModel_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"

/* Custom Type definition for MATLAB Function: '<S1>/X_dot_ext=f(V_in)' */
#ifndef struct_tag_sSn32Ib2fTarabZD2DajA7E
#define struct_tag_sSn32Ib2fTarabZD2DajA7E

struct tag_sSn32Ib2fTarabZD2DajA7E
{
  real_T breaks[73];
  real_T coefs[288];
};

#endif                                 /*struct_tag_sSn32Ib2fTarabZD2DajA7E*/

#ifndef typedef_sSn32Ib2fTarabZD2DajA7E_Edite_T
#define typedef_sSn32Ib2fTarabZD2DajA7E_Edite_T

typedef struct tag_sSn32Ib2fTarabZD2DajA7E sSn32Ib2fTarabZD2DajA7E_Edite_T;

#endif                                 /*typedef_sSn32Ib2fTarabZD2DajA7E_Edite_T*/

#ifndef struct_tag_syUNLkAcll3sMG1FvmbUBYC
#define struct_tag_syUNLkAcll3sMG1FvmbUBYC

struct tag_syUNLkAcll3sMG1FvmbUBYC
{
  real_T breaks[13];
  real_T coefs[48];
};

#endif                                 /*struct_tag_syUNLkAcll3sMG1FvmbUBYC*/

#ifndef typedef_syUNLkAcll3sMG1FvmbUBYC_Edite_T
#define typedef_syUNLkAcll3sMG1FvmbUBYC_Edite_T

typedef struct tag_syUNLkAcll3sMG1FvmbUBYC syUNLkAcll3sMG1FvmbUBYC_Edite_T;

#endif                                 /*typedef_syUNLkAcll3sMG1FvmbUBYC_Edite_T*/

/* Forward declaration for rtModel */
typedef struct tag_RTM_EditedSailingYachtModel_T
  RT_MODEL_EditedSailingYachtModel_T;

#endif                                 /* RTW_HEADER_EditedSailingYachtModel_types_h_ */
